import javax.xml.transform.Result;
import java.sql.*;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Pattern;

public class PG3 {
    private static Connection conn=null;
    private static Scanner sc = new Scanner(System.in);


    public static void connect() throws Exception{
        Class.forName("org.postgresql.Driver");
        conn = DriverManager.getConnection("jdbc:postgresql://comp421.cs.mcgill.ca:5432/cs421",
                "cs421g58", "8502QSbd");
    }
    public static void close() throws Exception{
        conn.close();
        System.out.println("closed");
    }

    public static boolean validifyEmail(String email)
    {
        String regex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                "[a-zA-Z0-9_+&*-]+)*@" +
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                "A-Z]{2,7}$";

        Pattern pat = Pattern.compile(regex);
        if (email == null)
            return false;
        return pat.matcher(email).matches();
    }

    public static boolean validifyPhone(String phone_number){
        String regex1 = "^[0-9]{10}$";
        String regex2 = "^(1\\-)?[0-9]{3}\\-?[0-9]{3}\\-?[0-9]{4}$";

        Pattern pat1 = Pattern.compile(regex1);
        Pattern pat2 = Pattern.compile(regex2);

        return pat1.matcher(phone_number).matches() || pat2.matcher(phone_number).matches();
    }

    public static String formatPhone(String phone_number){
        if(phone_number.length() == 12){
            return phone_number;
        }
        StringBuilder sb = new StringBuilder(phone_number);
        sb.insert(3, '-');
        sb.insert(7,'-');
        return sb.toString();
    }
    public static void register() throws SQLException {

        PreparedStatement emailDup = conn.prepareStatement("SELECT * FROM client WHERE client.email = ? ");
        PreparedStatement phoneDup = conn.prepareStatement("SELECT * FROM client WHERE client.user_phone_number = ? ");
        PreparedStatement insertion = conn.prepareStatement("INSERT INTO client VALUES (?,?,?,?,?)");
        PreparedStatement userid = conn.prepareStatement("SELECT * FROM client WHERE user_id = ?");
        System.out.println("Please enter your Last name");
        String last_name = sc.nextLine();
        System.out.println("Please enter your first name");
        String first_name = sc.nextLine();

        //
        String email;
        while(true) {
            System.out.println("Please enter your email address");
            email = sc.nextLine();
            while (!validifyEmail(email)) {
                System.out.println("please enter an correct email, recommend Gmail, outlook." +
                        "if you want to quit, please enter 'q'.");
                email = sc.nextLine();
                if (email.equals("q")) {
                    emailDup.close();
                    phoneDup.close();
                    insertion.close();
                    userid.close();
                    //sc.close();
                    return;
                }
            }

            emailDup.setString(1, email);

            ResultSet rs = emailDup.executeQuery();
            int counter = 0;
            while (rs.next()) {
                System.out.print(rs.getString("email"));
                counter++;
                break;
            }
            if (counter == 0) {
                break;
            } else {
                System.out.println("The email has already been registered");
                counter = 0;
            }
        }
        //
        String phone_number;
        while(true) {
            System.out.println("Please enter your phone number");
            phone_number = sc.nextLine();
            while (!validifyPhone(phone_number)) {
                System.out.println("Please entern an correct phone number." +
                        "If you want to quit, please enter 'q'.");
                phone_number = sc.nextLine();
                if (phone_number.equals("q")) {
                    emailDup.close();
                    phoneDup.close();
                    insertion.close();
                    userid.close();

                    return;
                }
            }
            String format_phone = formatPhone(phone_number);

            phoneDup.setString(1,format_phone);
            ResultSet rs = phoneDup.executeQuery();
            int counter = 0;
            while(rs.next()){
                counter++;
                System.out.print(rs.getString("user_phone_number"));

            }
            if(counter != 0) {
                System.out.println("This phone number is taken");
                counter = 0;
            }else{
                phone_number = format_phone;
                break;
            }
        }

        Random random = new Random();
        int number;
        while (true){
            number = random.nextInt(1000000);
            userid.setInt(1,number);
            ResultSet rs = userid.executeQuery();
            int counter = 0;
            while(rs.next()){
                counter ++;
            }
            if(counter ==0){
                break;
            }
            counter = 0;
        }
        insertion.setInt(1,number);
        insertion.setString(2,first_name);
        insertion.setString(3,last_name);
        insertion.setString(4,phone_number);
        insertion.setString(5,email);
        insertion.executeUpdate();
        System.out.println("The user's id is "+ number);

        emailDup.close();
        phoneDup.close();
        insertion.close();
        userid.close();
    }

    public static void search_favoriate() throws SQLException {
        PreparedStatement search = conn.prepareStatement("SELECT r.description as name,r.restaurant_id, count(*) as count\n" +
                "FROM contain_dish_order c, orders o,restaurant r\n" +
                "WHERE c.order_id = o.order_id AND r.restaurant_id = c.restaurant_id AND o.user_id = ?\n" +
                "GROUP BY r.restaurant_id\n" +
                "ORDER BY count DESC ");
        System.out.println("please enter user ID");
        String input = sc.nextLine();
        int id = Integer.valueOf(input);
        if(id <100000|| id>999999){
            System.out.println("User Id invalid");
            search.close();
            return;
        }
        search.setInt(1,id);
        ResultSet rs= search.executeQuery();
        boolean flag = false;
        if(rs.next()){
            flag = true;
            String restaurant = rs.getString("name");
            String count = rs.getString("count");

            System.out.println("The user's favorite restaurant is "+ restaurant);
            System.out.println("S/he has ordered "+ count + " times");
        }
        if(!flag){
            System.out.println("Can't find any related order this user make");
        }
        search.close();

    }

    public static void rate_driver() throws SQLException{
        PreparedStatement drivingInfo = conn.prepareStatement("SELECT AVG(o.actual_arrival_time) as atime, avg(o.estimated_arrival_time) as etime, avg(o.driver_rating) as rate, d.driver_name as name\n" +
                "FROM orders o,driving d\n" +
                "WHERE o.driver_id = d.driver_id AND d.driver_id = ?\n" +
                "GROUP BY o.driver_id, d.driver_name");

        System.out.println("please enter an driver id");
        String input = sc.nextLine();
        int id = Integer.valueOf(input);
        if(id >999999|| id < 100000){
            System.out.println("Invalid driver id");
            drivingInfo.close();
            return;
        }
        drivingInfo.setInt(1,id);
        ResultSet rs = drivingInfo.executeQuery();
        boolean flag = false;
        if(rs.next()){
            flag = true;
            Time atime = rs.getTime("atime");
            Time etime = rs.getTime("etime");
            float rate = rs.getFloat("rate");
            String name = rs.getString("name");
            long atime1 = atime.getTime();
            long etime1 = etime.getTime();
            long diff = atime1-etime1;
            diff/=1000;
            long minute = diff/60;
            long sec = diff%60;

            System.out.print(name+" has a rating of "+ rate);
            if(diff>0){
                System.out.println(". On average, he is " + Math.abs(minute) +" minutes "+sec+ " seconds late");
            }else{
                System.out.println(". On average, he arrives "+ Math.abs(minute)+ " minutes"+sec+" seconds early");
            }



        }
        if(!flag){
            System.out.println("The driver has not delivered anything yet");
        }
        drivingInfo.close();

    }

    public static void searchFood()throws SQLException{
        System.out.println("please enter a region code");
        String input = sc.nextLine();
        int code = Integer.valueOf(input);

        if(code <100||code>999){
            System.out.println("Invalid region code");
            return;
        }
        String reg_code =code+"";
        System.out.println("Please enter the key words");
        input = sc.nextLine();
        PreparedStatement search = conn.prepareStatement("SELECT d.dish_name as dish_name,res.description as restaurant_name, d.dish_price as price\n" +
                "FROM region reg, restaurant res, dish d\n" +
                "WHERE reg.region_code = res.region_code AND res.restaurant_id = d.restaurant_id\n" +
                "AND res.region_code = ?AND d.dish_name ILIKE '%"+input +"%'\n");

        search.setString(1,reg_code);

        ResultSet rs = search.executeQuery();
        int counter = 0;
        while(rs.next()){
            System.out.println(counter + ". " +rs.getString("dish_name") + " from " +rs.getString("restaurant_name")+ " at "+ rs.getString("price"));
            counter ++;
        }
        if(counter == 0){
            System.out.println("Sorry, you can any relevent dish in the area");
        }
        search.close();
    }

    public static void calculate_tipssum() throws SQLException{
        System.out.println("Please enter the driver's id");
        int driverid = sc.nextInt();
        if(driverid<100000|| driverid>999999){
            System.out.println("Invalid driver id");
            return;
        }
        PreparedStatement calculate = conn.prepareStatement("SELECT d.driver_id, d.driver_name as name, SUM(o.tips) as proceeds\n" +
                "FROM driving d, orders o\n" +
                "WHERE d.driver_id = o.driver_id AND d.driver_id = ?\n" +
                "GROUP BY d.driver_id");

        calculate.setInt(1,driverid);
        ResultSet rs = calculate.executeQuery();

        if(rs.next()){
            String name = rs.getString("name");
            float proceeds = rs.getFloat("proceeds");
            System.out.println(name+ " whose driver id is "+driverid+" has proceeds of " + proceeds+" from tips");
        }else{
            System.out.println("Sorry, there's no information about this driver's proceeds");
        }
        calculate.close();
    }



    public static void display(){
        System.out.println("Welcome to Uber Database management inerface");
        System.out.println("Please choose the following fuction");
        System.out.println("A. Register a user");
        System.out.println("B. Search a user's favorite restaurant");
        System.out.println("C. Evaluate a driver based on delivery time and rate");
        System.out.println("D. Search a food using key word in certain area");
        System.out.println("E. Calculate the total proceeds of a driver");
        System.out.println("F. Quit");
    }

    public static String IO(){
        System.out.println("please enter a number from 1-6");

        String input ="";
        while(sc.hasNextLine()){
            input = sc.nextLine();
            if(input.equals("A")||input.equals("B")||input.equals("C")||input.equals("D")||input.equals("E")||input.equals("F")){
                break;
            }
            System.out.println("please enter a number from 1-6");


        }
        return input;
    }
    public static void main(String []args) throws Exception {


        try{
            connect();
            while(true){
                display();
                String input = IO();

                    if (input.equals("A")) {
                        register();
                    } else if (input.equals("B")) {
                        search_favoriate();
                    } else if (input.equals("C")) {
                        rate_driver();
                    } else if (input.equals("D")) {
                        searchFood();
                    } else if (input.equals("E")) {
                        calculate_tipssum();
                    } else if (input.equals("F")) {
                        System.out.println("quiting");
                        System.exit(0);
                        break;
                    } else {
                        System.out.println("try again");
                    }



            }
            sc.close();

            close();
        }catch (Exception e){
            e.printStackTrace();
        }


    }
}
